package com.example.cocass_inputs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Rest of onCreate
        //create the spinner

        Spinner spinner = findViewById(R.id.label_spinner);
        if (spinner != null) {
            spinner.setOnItemSelectedListener(this);
        }
        //Create ArrayAdapter using the string array and default spinner layout.
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
            R.array.label_array, android.R.layout.simple_spinner_item);

        //specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        //apply the adapter to the spinner
        if (spinner != null) {
            spinner.setAdapter(adapter);
        }
    }

    public void onSubmit(View view) {
        if (((CheckBox) findViewById(R.id.checkbox1_chocolate_syrup)).isChecked()) {
            Toast.makeText(this,
                    getString(R.string.chocolate_syrup),
                    Toast.LENGTH_SHORT).show();
        }


        if (((CheckBox) findViewById(R.id.checkbox2_sprinkles)).isChecked()) {
            Toast.makeText(this,
                    getString(R.string.sprinkles),
                    Toast.LENGTH_SHORT).show();
        }


        if (((CheckBox) findViewById(R.id.checkbox3_nuts)).isChecked()) {
            Toast.makeText(this,
                    getString(R.string.crushed_nuts),
                    Toast.LENGTH_SHORT).show();

        }
    }

    public void onRadiobuttonClicked(View view) {
        if (view.getId() == R.id.sameday){
            Toast.makeText(this, getString(R.string.same_day_messenger),
                    Toast.LENGTH_SHORT).show();
            }

        if (view.getId() == R.id.nextday) {
            Toast.makeText(this, getString(R.string.next_day_ground_delivery),
                    Toast.LENGTH_SHORT).show();
            }

        if (view.getId() == R.id.pickup) {
            Toast.makeText(this, getString(R.string.pickup),
                    Toast.LENGTH_SHORT).show();
            }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
    String spinner_item = adapterView.getItemAtPosition(i).toString();
    //Do something with the spinner_item strin
        Toast.makeText(this,
                spinner_item,
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void onToggleClicked(View view) {
        ToggleButton toggle = findViewById(R.id.my_toggle);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                StringBuffer onOff = new StringBuffer().append("On or Off?");
                if (isChecked){//The toggle is enabled
                    onOff.append("On");
                }
                else { // The toggle is disabled
                    onOff.append("Off ");
            }
                Toast.makeText(getApplicationContext(),onOff.toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void onSwitchClick(View view) {
        Switch aSwitch = findViewById(R.id.my_switch);
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                StringBuffer onOff = new StringBuffer().append("On or Off? ");
                if (isChecked) { //The switch is enabled
                    onOff.append("On ");
                } else { //The switch is disabled
                    onOff.append("Off ");
                }
                Toast.makeText(getApplicationContext(), onOff.toString(),
                        Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

